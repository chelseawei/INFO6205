public class Pell {
    public Pell() {
    }
    public long get(int n) {
        if (n < 0)
            throw new UnsupportedOperationException("Pell.get is not supported for negative n");

        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }


        long[] a = new long[n + 1];
        a[0] = 0;
        a[1] = 1;

        for (int i = 2; i <= n; i++) {
            a[i] = 2 * a[i - 1] + a[i - 2];
        }

        return a[n];
    }



}
